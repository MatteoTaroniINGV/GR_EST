function [ NumberEvents , Times ] = Weichert_Input( Catalog , CompletenessMatrix , CatalogEndingYear , MagnitudeVector )

% This function computes for each magnitude bin the number of events in the
% bin and the time length (in year) of the bin

% INPUT
%
% Catalog :  seismic catalog in ZMAP format
%
% CompletenessMatrix : the matrix with the completeness info in two-columns
% format: 1) Magnitude    2) Starting time (in year) of the completeness
%
% CatalogEndingYear : end year of the catalog (that is not necessary the
% year of the last earthquake in the catalog)
%
% MagnitudeVector : vector with the magnitudes of each bin  
% (e.g. [ 3.0 : 0.1 : 7.5 ] ) 

% OUTPUT
%
% NumberEvents : number of events in each magnitude bin; note that the 
% length of this vector is smaller (one less value) respect to the vector
% 'MagnitudeVector', beacuse it counts the number of events with magnitude 
%  >= i-th magnitude and < i+1-th magnitude.
%
% Times : time length (in year) of each magnitude bin; note that the length
% of this vector is smaller (one less value) respect to the vector 
% 'MagnitudeVector', as in 'NumberEvents'


for i = 1 : length( MagnitudeVector ) - 1
    
    % compute the number of events of the i-th magnitude bin
    NumberEvents( i ) = size( Catalog( Catalog( : , 6 ) > MagnitudeVector( i ) - 10^(-6) &...
                                       Catalog( : , 6 ) < MagnitudeVector( i + 1 ) , : ) , 1 ) ; 

    % find the Index of the line in 'CompletenessMatrix' corresponding to
    % the i-th magnitude bin
    %[ Value , Index ] = min( abs( CompletenessMatrix( : , 1 ) - MagnitudeVector( i ) ) ) ; 
    Index = find( ( MagnitudeVector( i ) - CompletenessMatrix( : , 1 ) ) > ( 0 - 10^(-6) ) , 1 ) ;
    
    % compute the time length (in year) of the i-th magnitude bin  
    Times( i ) = CatalogEndingYear - CompletenessMatrix( Index , 2 ) + 1 ;                           
end





