Example 4 shows how to compute the uncertainty estimation for Lambda, Beta and Corner Magnitude parameter of the tapered GR distribution, from a seismic catalog with variable completeness time windows. 
It uses the Wiechert 1980 approach.

To produce the plot with observed annual rate and the estimated uncertainty on tapered GR distribution ( 2.5, 50 and 97.5 percentiles curves), follow the instructions below:

1) run the script: Script_TaperedGR_Weichert_uncert.m
   This script compute the uncertainty estimation for Lambda, Beta and Corner Magnitude parameter of the Tapered GR distribution.
   This script uses the functions: LL_TaperedGR_Weichert_MCMC.m, Weichert_Input.m, CumulativeAnnualRate_plot.m, MCMC_ver2.m, TaperedGR_uncert_plot.m
   The function LL_TaperedGR_Weichert_MCMC.m is very similar to LL_TaperedGR_Weichert.m, but to avoid computational problems there is 
   a maximum allowed Corner Magnitude and is not possible to have a negative values of Lambda and Beta.
   Input: seismic catalog, matrix of completeness, ending year of the catalog, vector of the magnitude bins;
   Output: figure (magnitude vs log10 cumulative number of events plot) with observations and the estimated function with uncertainties, 
           vectors with the MCMC estimation of the parameters;


2) Exploration of MCMC output statistics: if you want to take a look to the uncertainty associated with each parameter, run the command line in the command window: 
   
   hist( LambdaVector )
   hist( BetaVector )
   hist( CornerMagnitudeVector )


3)  Exploration of MCMC output statistics: If you want to take a look to the uncertainty associated with two parameters together, run the command line in the command window:   

   scatter( LambdaVector , BetaVector )
   scatter( CornerMagnitudeVector , BetaVector )
   scatter( CornerMagnitudeVector , LambdaVector )


