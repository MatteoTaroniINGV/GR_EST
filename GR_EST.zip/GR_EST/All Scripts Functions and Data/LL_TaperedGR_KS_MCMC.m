function LL = LL_TaperedGR_KS_MCMC( Catalog , CompletenessMatrix , CatalogEndingYear , Lambda , Beta , CornerMagnitude )

% This function computes the log-likelihood of Tapered Gutenberg-Richter 
% distribution with the Kijko-Sellevol method for the MCMC uncertainty
% computation: in this case there is an upper maximum value for the Corner
% Magnitude to avoid computational problems (in the last part of the code
% is possible to change this value; by default set to Mw = 10.0 ) and a
% cutoff for unphysical negative values of Lambda and Beta

% INPUT
%
% Catalog : seismic catalog in ZMAP format
% 
% CompletenessMatrix : completeness matrix in the two-columns format:
%                            1                    2
%                        Magnitude      Starting year of completenss
%
% CatalogEndingYear : last year of the seismic catalog
%
% Lambda : annual rate of the events
%
% Beta : parameter of the Tapered GR distribution
%
% CornerMagnitude : parameter of the Tapered GR distribution

% OUTPUT
%
% LL : log-likelihood of the Tapered GR distribution given the parameters 
% computed using the Kijko-Sellevoll approach


% convert magnitudes to moments (the specific law used in this conversion
% do not affect the final computation)
MagnitudesM = 10.^( 3/2*( Catalog(:,6) + 10.733) ) ;            % convert magnitudes to seismic moment
CornerMagnM = 10.^( 3/2*( CornerMagnitude + 10.733) ) ;         % convert corner magnitude to seismic moment
MagnComplM  = 10.^( 3/2*( CompletenessMatrix(:,1) + 10.733) ) ; % convert magnitudes of completeness to seismic moments

for i = 1 : size( CompletenessMatrix , 1 )

    if i == size( CompletenessMatrix , 1 )
        
        % select the events in the correct moment-time window
        Mom_Sub_Catalog = MagnitudesM( MagnitudesM > MagnComplM(i) - 10^(-6) & ...
                          Catalog(:,3) > CompletenessMatrix(i,2) - 10^(-6)  ) ;
          
        % number of events in the sub-catalog
        Num = length( Mom_Sub_Catalog ) ;
        
        % time length(in year) of the sub-catalog
        Time = CatalogEndingYear - CompletenessMatrix(i,2) + 1 ;
        
        % log-likelihood for the moment distribution
        L_M = Num*Beta*log( MagnComplM(i) ) + 1/CornerMagnM*( Num*MagnComplM(i) - sum( Mom_Sub_Catalog ) ) - ...
              Beta*sum( log( Mom_Sub_Catalog ) ) + sum( log( Beta./Mom_Sub_Catalog+1/CornerMagnM ) ) ;
        
        % ni (parameter for the log-likelihood computation)   
        ni = Lambda* ( ( ( ( MagnComplM(i) ).^( -1 ) ).*MagnComplM(end) ).^Beta ).*...
             exp( ( MagnComplM(end) - MagnComplM(i) )./CornerMagnM ) ;
          
        % log-likelihood for the number of events distribution
        L_N = -ni*Time + Num*log( ni*Time ) ;
        
        % joint log-likelihood
        LL_Sub_Catalog( i ) = L_M + L_N ;
        
    else
        % select the events in the correct moment-time window
        Mom_Sub_Catalog = MagnitudesM( (MagnitudesM > MagnComplM(i) - 10^(-6)) & ...
                          (Catalog(:,3) > CompletenessMatrix(i,2) - 10^(-6))   & ...
                          (Catalog(:,3) < CompletenessMatrix(i+1,2)) ) ;
          
        % number of events in the sub-catalog
        Num = length( Mom_Sub_Catalog ) ;
        
        % time length(in year) of the sub-catalog
        Time = CompletenessMatrix(i+1,2) - CompletenessMatrix(i,2) + 1 ;
        
        % log-likelihood for the moment distribution
        L_M = Num*Beta*log( MagnComplM(i) ) + 1/CornerMagnM*( Num*MagnComplM(i) - sum( Mom_Sub_Catalog ) ) - ...
              Beta*sum( log( Mom_Sub_Catalog ) ) + sum( log( Beta./Mom_Sub_Catalog+1/CornerMagnM ) ) ;
        
        % ni (parameter for the log-likelihood computation)   
        ni = Lambda* ( ( ( ( MagnComplM(i) ).^( -1 ) ).*MagnComplM(end) ).^Beta ).*...
             exp( ( MagnComplM(end) - MagnComplM(i) )./CornerMagnM ) ;
          
        % log-likelihood for the number of events distribution
        L_N = -ni*Time + Num*log( ni*Time ) ;
        
        % joint log-likelihood
        LL_Sub_Catalog( i ) = L_M + L_N ;              
    end
end

% compute the final log-likelihood
LL = sum( LL_Sub_Catalog ) ;

% assign a zero value for the likelihood if 'CornerMagnitude' is bigger 
% than a critical value or Lambda or Beta are <= 0
if CornerMagnitude >= 10.0 || Lambda <= 0 || Beta <= 0
    
    LL = log( 0 ) ;
    
end
        