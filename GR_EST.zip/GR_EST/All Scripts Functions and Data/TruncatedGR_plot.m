function TruncatedGR_plot( MagnitudeVector , Lambda , Bvalue )
    
% This function plots the cumulative Truncated Gutenberg-Richter distribution
% in a logartihmc scale

% INPUT 
%
% MagnitudeVector : vector with the magnitudes of each bin 
% !!! The maximum of the magnitude vector is also the maximum magnitude in
%     the Weichert method !!!  
%
% Lambda : annual rate of the events
%
% Bvalue : parameter of the Truncated GR distribution

  
% cdf of the Truncated GR distribution
F = ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*MagnitudeVector)))./...  
    ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*max(MagnitudeVector)))) ;

% logarithmic plot of the cumulative Tapered GR distribution
plot( MagnitudeVector , log10( ( 1 - F ).*Lambda ) , 'r' ) 