% Script for earthquake catalog simulation, with Poisson distribution of
% the events and Truncated Gutenberg-Richter distribution of the magnitudes.
% Output catalog in ZMAP format

% ZMAP format:
%     1         2        3     4     5       6        7     8      9      10
% Longitude  Latitude  Year  Month  Day  Magnitude  Depth  Hour  Minute  Second

% starting date of the catalog ;
% format: year  month  day  hour  minute  second
StartingDate = [ 1000  1  1  0  0  0 ] ;

% annual rate of the events above the magnitude of completeness
AnnualRate = 100 ;

% longitude and latitude (the same for all events)
Longitude = 15 ;
Latitude  = 40 ;

% depth (the same for all events)
Depth = 10 ;

% magnitude of completeness of the catalog
MagnMin = 3.0 ;

% parameters of the Truncated GR distribution:
% maximum magnitude and beta
MagnMax = 7.0 ;
Bvalue  = 1.0 ;

% number of events in the catalog
NumbEvents = 10^5 ;


% preallocation of the simulated catalog
Catalog = zeros( NumbEvents , 10 ) ;

% initial time for the simulation 
Time = 0 ;

for i = 1 : NumbEvents
    
    % random time from exponential distribution (Poisson distribution has
    % exponential interevent time)
    Time = Time + ( exprnd( 1/ ( AnnualRate ) ) ) * 365.25 ;

    % simulated date
    NewDate = datevec( datenum( StartingDate ) + Time ) ;
    
    
    %%% simulated magnitude from Truncated GR distribution %%%%%%%
    
    Magnitude = -1 / ( Bvalue * log(10) ) * log( 1 - rand ) + MagnMin ;
    
    while Magnitude > MagnMax
        
          Magnitude = -1 / ( Bvalue * log(10) ) * log( 1 - rand ) + MagnMin ;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                  

    % catalog info
    Catalog( i ,  1 ) = Longitude ;
    Catalog( i ,  2 ) = Latitude ;
    Catalog( i ,  3 ) = NewDate( 1 ) ;
    Catalog( i ,  4 ) = NewDate( 2 ) ;
    Catalog( i ,  5 ) = NewDate( 3 ) ;
    Catalog( i ,  6 ) = Magnitude ;
    Catalog( i ,  7 ) = Depth ;
    Catalog( i ,  8 ) = NewDate( 4 ) ;
    Catalog( i ,  9 ) = NewDate( 5 ) ;
    Catalog( i , 10 ) = NewDate( 6 ) ;
end
