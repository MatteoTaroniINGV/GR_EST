function LL = LL_TruncatedGR_Weichert( MagnitudeVector , NumberEvents , Times , Lambda , Bvalue )

% This function computes the log-likelihood of Truncated Gutenberg-Richter 
% distribution with the Weichert method.

% INPUT
%
% MagnitudeVector : vector with the magnitudes of each bin  
% (e.g. [ 3.0 : 0.1 : 7.5 ] ). 
% !!! The maximum of the magnitude vector is also the maximum magnitude in
%     the Weichert method !!!   
% 
% NumberEvents : output of the 'Weichert_Input' function
%
% Times : output of the 'Weichert_Input' function
%
% Lambda : annual rate of the events
%
% Bvalue : parameter of the Truncated GR distribution

% OUTPUT
%
% LL : log-likelihood of the Truncated GR distribution given the parameters 
% computed using the Weichert approach


% pre-computation of the factorial logarithm to avoid overflow problem
for k = 1 : size( NumberEvents )
    
    if NumberEvents(k) > 0
    
        LOGFACT(k) = sum( log( [ NumberEvents(k) : -1 : 1 ] ) ) ;
    
    else
        LOGFACT(k) = 0;
    end
end
%


% compute the probability vector (in this case it uses the Truncated GR
% distribution)
Pr = ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*MagnitudeVector(2:end  ))))./...  
     ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*max(MagnitudeVector))))  - ...
     ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*MagnitudeVector(1:end-1))))./...  
     ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*max(MagnitudeVector)))) ;

% compute the log-likelihood using the Weichert approach
LL = sum(NumberEvents)*log(Lambda) - Lambda*sum(Pr.*Times) +...
     sum(NumberEvents.*log(Pr.*Times) - LOGFACT ) ;
             


