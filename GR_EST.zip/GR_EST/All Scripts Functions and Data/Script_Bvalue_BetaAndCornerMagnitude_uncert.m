% Script that computes the b-value of Gutenberg-Richter law and its error
% and the parameters of the Tapered Gutenberg-Richter law and their 95%
% confidence interval. No Poisson assumption needed for this computation

% load the seismic catalog
Catalog = load( 'Catalog_Simulation_Ex2.txt' ) ;

% the magnitude column of the catalog
MagnitudeColumn = 6 ;

% minimum magnitude of completeness of the catalog
MagnMin = 3.0 ;

% magnitude bin
Bin = 0 ;

% compute b-value of Gutenberg-Richter law and its error
[ B , N , Sigma ] = Bvalue_Estimation_uncert( Catalog , MagnitudeColumn , MagnMin , Bin ) ;

% possible values of the parameters for the confidence interval estimation
BetaVector            = 0.6 : 0.001 : 0.75 ;
CornerMagnitudeVector = 5.0 : 0.1 : 10 ;

% plot the 95% confidence interval of the parameters of Tapered 
% Gutenberg-Richter law using the "profile likeilhood method"
TaperedGR_Estimation_uncert( Catalog , MagnitudeColumn , MagnMin , BetaVector , CornerMagnitudeVector ) ;