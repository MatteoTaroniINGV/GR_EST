%% Script to generate a Monte Carlo Markov Chain to sample from an unknown probability distribution
% The guess function is a Normal distribution with different sigma for the different variates.
% The distribution to be sample is given logarithminc.

function [xout,figout] = MCMC_uncert_Estimation(Ncamp,par0,logPfun,sigma,parName)
% Ncamp: sample size
% par0: starting point for the Markov Chain (vector with n variates); logPfun(par0) must be real (neither NaN nor +/-inf) 
% logPfun(par): function containing the logaritm of the distribution to be sampled (prior, log-likelihood, or posterior), as a function of a input point (vector with n variates)
% sigma: vector containing a starging guess for the standard deviation of the gaussian guess function (vector, one value per variate); this parameter will be tuned.
% parName: list of names for each parameter (for plotting)

%% EXAMPLE
%mu = [2 0]; Sigma = [.25 .3; .3 1];
%LL = {@( par) log( mvnpdf(par,mu,Sigma) )};          
%nsample = 1000; par0=  [0.5 , 1 ]; sigmaGuess = [ 0.1 , 0.1]; par_names = { 'X' , 'Y' };
%[xout,figout] = MCMC(nsample,par0,LL,sigmaGuess,par_names) ; 

%% GENERAL SETTINGS
% maximum number of iterations
  Nmax = 1.E6;  
% number of variates
  npar = length(par0); 
% to store the entire chain, initialized to zeros  
  x_chain = zeros(Nmax,npar);   
% to store current value of the chain, initialized to par0
  x=par0; 
% to store the sample in output
  xout = zeros(Ncamp,npar);
% to store iteration when sampling starts
  istart=Nmax;  
% find if it is runnign on Octave or Matlab
  tmp = ver;
  octaveYN = not(isempty(strfind([tmp(:).Name],'Octave')));

%% SETTINGS FOR SAMPLING
  % to control the start of sampling
  samplingYN = false; 
  % to count sample size
  nsample = 0;
  % definition of guess function
  guessFun = @(par,sigma) normrnd(par,sigma); 
  
%% SETTINGS FOR TUNING
  % to control tuning
  tuningYN = true;   
  % frequency of tuning for the variance of proposal
  Ntun=500;itun=0; 
  tune_on=100*ones(size(par0));
  tune_on_all = 100;
  % target interval for acceptance to stop tuning
  targetAccIn = [0.05 0.10];
  % set target overall acceptance
  targetAcc = targetAccIn;
  % set target acceptance for each parameter (equally distributed)
  targetAccPar = targetAccIn.^(1/npar);   
  % to initialize the number of acceptances of single variates
  nacc0=zeros(size(par0));
  % to store the number of acceptances of single variates 
  nacc = nacc0; 
  % to store the number of global acceptance (all variates), initialized to 0
  naccAll = 0; 
  % to store the first sample in which to evaluate the acceptance ratio
  iold=1;
  % to store the ratio of acceptances of single variates
  ratio=0.;
  % to store the ratio of global acceptance (all variates)
  ratioAll=0.;

%% SETTING FOR BURN-IN
  % number of samples to check burn-in    
  Nave=100; 
  % to store averages (burn-in)
  xave = zeros(2*Nave,npar);
  % to count the number of samples to compute average
  iave = 0; 

    
%% SETTINGS FOR PRODUCING PLOTS
  figYN = false ; % true to activate plotting
  Nplot=Ntun;     % number of cycles to update plots (if present)  
  if figYN
     scrsz = get(0,'ScreenSize');
     f2=figure();
     set(f2,'Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)*2/3]);
     f2first = true;
     f3=figure();
     f4=figure();
     figout = [f2,f3,f4];
     col = colormap(lines(npar));
    if octaveYN
      pkg load statistics
      graphics_toolkit('gnuplot')
    end  
  else
     figout = -1;
  end


%% START SIMULATION
  % loop over all possible runs 
  for i=1:Nmax
    % update chain
    x_chain(i,:) = x;    

    % if necessary, update plots
    if figYN
      if mod(i,Nplot)==0 && i > 1
      % evaluttion of rates of acceptance (per variate and global), to be plotted
        ratioPlot = nacc / (i-iold);        
        ratioAllPlot = naccAll / (i-iold);   
        % store present value of the chain
        parNowPlot =  x_chain(iold:i,:);

        figure(f2)
        subplot(2,1,1);  
        for ii=1:npar
          plot(iold:i,parNowPlot(:,ii),'Color',col(ii,:)); hold on;
        end
        if sum(tune_on) > 50
          subplot(2,2,3); 
          plot(i,ratioAllPlot,'ok')
          for ipar=1:npar
            plot(i,ratioPlot(ipar),'x','Color',col(ipar,:)); hold on;
            plot([i i],targetAcc,'.k');
            plot([i i],targetAccPar,'.r');
          end
          subplot(2,2,4); 
          for ipar=1:npar
            plot(i,sigma(ipar),'x','Color',col(ipar,:)); hold on;
          end
          grid
        end
        pause(10)
            
        % to initialize plots (titles, lables, etc.)
        if f2first
          f2first = false;
          subplot(2,1,1)
          title('chain'); hold on;
          for ii=1:npar
            if length(parName{ii}) == 0
              parLeg{ii} = ['Par #' num2str(ii)];
            else
              parLeg{ii} = parName{ii};
            end
          end
          legend(parLeg,'Location','westoutside')   
          subplot(2,2,3)
          title('acceptance ratio'); hold on;
          set(gca,'YLim',[0,1]);
          subplot(2,2,4)                
          title('Sigma of guess functions'); hold on;
          set(gca,'YScale','log')
        end
   
      end
    end


%% EXIT CRITERION
    % exit if the target sample size has been reached
    if nsample == Ncamp
      out0=['nsample = ',num2str(Ncamp)]; disp(out0);
%     out0=['Results in xout']; disp(out0);

      % finalize plots, if any
      if figYN
        figure(f3)
        for ii=1:npar
          subplot(npar,1,ii)
          hist(xout(:,ii),max(round(Ncamp/200),10))
          hold on
          title(['Mean ',num2str(mean(xout(:,ii))),', Median ',num2str(median(xout(:,ii)))])
          xlabel(parName{ii})
        end
          
        figure(f4)  
        iplot=0;
%            ntot=factorial(npar)/factorial(2);
        ntot=(npar^2-npar)/2;
        nrows = ceil(sqrt(ntot));
        ncols = ceil(ntot/nrows);
        nbinsnnn=10;
        for ipar1=1:npar-1
          for ipar2=ipar1+1:npar
            iplot = iplot+1;
            subplot(ncols,nrows,iplot)
            plot(xout(:,ipar1),xout(:,ipar2),'.') 
            hold on
%            plot(parLS(1),parLS(2),'rx')
%            plot(parML(1),parML(2),'cx')                   
             [n,c] = hist3([xout(:,ipar1),xout(:,ipar2)],[nbinsnnn,nbinsnnn]);
            contourf(c{1},c{2},n',nbinsnnn)                                     
            hold on
            contour(c{1},c{2},n',nbinsnnn)                                     
            title([num2str(ipar1) ' - ' num2str(ipar2)])
            xlabel(parName{ipar1})
            ylabel(parName{ipar2})          
          end
        end
      end

      return
    end

%% TUNELLING ACCEPTANCE DISTRIBUTION VARIANCE
    % performe tuneling only if activated (not during sampling)
    itun=itun+1;         
    if tuningYN && itun == Ntun
        % evaluttion of rates of acceptance (per variate and global)
        ratio = nacc / (i-iold);
        ratioAll = naccAll / (i-iold);
        
        % reset counts
        itun=0;
        iold = i;
        nacc = nacc0;
        naccAll = 0;
        
        if tune_on_all > 50
            for ipar=1:npar
                if sum(tune_on) > 50
                    if ratio(ipar) > targetAccPar(2)
                        sigma(ipar) = sigma(ipar) * 1.1;
                    elseif ratio(ipar) < targetAccPar(1)
                        sigma(ipar) = sigma(ipar) * 0.9;
                    else
                        tune_on(ipar) = 0;
                    end
                end
            end
        end
        if sum(tune_on) < 50
            if ratioAll > targetAcc(2) || ratioAll < targetAcc(1)
                tune_on(:) = 100;
            else
                tune_on_all = 0;
            end
        else
            
        end
        if tune_on_all + sum(tune_on) < 50
            tuningYN = false;
        end
       
    end

%% CHECK FOR BURN-IN 
    % burn-in is checked only if tuning has finished, sampling has not started yet, and we have enough data
    if not(tuningYN) && not(samplingYN) && iave == 2*Nave
        % to check if the chain is steady, we use a ks2 (2 tails Kolmogorov Smirnov) test for each variate
        for ii=1:npar
           x1 = xave(1:Nave,ii);
           x2 = xave(Nave+1:end,ii);
           if octaveYN
              [p(ii),h] = kolmogorov_smirnov_test_2(x1,x2);
           else
              [h,p(ii)] = kstest2(x1,x2);
           end           
        end

        % if alpha is > 0.05 for all variates, we stop burn in and start sampling
        if length(find(p>0.05)) == length(p)
            % activate sampling
            samplingYN = true;
            % store the index of first sample
            istart = i;
            % write a message in standard output
            out0=['Start sampling']; disp(out0);
            % update figure, if any
            if figYN
               % plot line of sampling started
               subplot(2,1,1)
               ylim = get(gca,'YLim'); plot(istart*ones(2,1),ylim,'k-');
            end
        else 
            % write a message in standard output with results of ks2 test
%             disp(['KS2 failed: ' num2str(p)])
        end

        % take the second set as first set of next check of burn-in, if necessary
        iave = Nave;
        xave(1:Nave,:)=xave(Nave+1:end,:);
    end


%% COMPUTE NEW CANDIDATE FOR THE CHAIN   
      % to store accepted points
      xnew = x;
      % store the number of variates for which the new point is accepted 
      iacc = 0;
      % update the variates independently
      for ipar = 1:npar     
          % sample a new set of possible variates from guess distribution 
          tmp = guessFun(x,sigma);
          % new candidate point is the last accepted point, updated for the selected variate only
          xtry = xnew;
          xtry(ipar) = tmp(ipar);        
          % evaluate the acceptance
          accepted = evalPoint(xtry,x,logPfun);            
          if accepted
             % update new candidate, if new variate accepted
             xnew(ipar) = xtry(ipar);
             % update counting of acceptance for this variate
             nacc(ipar) = nacc(ipar)+1;
             % update counting of accepted variates
             iacc=iacc+1;
          end
      end
      % accept new point only if all variates are accepted
      if iacc == npar
         % update counting of acceptances for tuning
         naccAll = naccAll +1;
         if samplingYN
            % if sampling, store the new point and update counting
            nsample = nsample + 1;
            xout(nsample,:) = xnew;
         elseif not(tuningYN)
            % if not sampling and not tuning, updated the number of points in the new set buring-in (index and value)
            iave = iave+1;
            xave(iave,:) = xnew;                     
         end
      end
      % set current point to the last accepted point (not necessarily accepted for sampling, that is, chaning all variates)
      x = xnew;      
      
  end
end


function accepted = evalPoint(xNew,xOld,logPfun)
%% Acceptance function
 
    % initialize to non accepted  
    accepted = false;

    % compute log-pdf for new point 
    Fnew = logPfun{1}(xNew);
    if abs(Fnew) < inf 
       % compare log-pdf of new and old points 
       a1 = logPfun{1}(xNew) - logPfun{1}(xOld);
    else
       % if the new log-pdf is inf or -inf, force to not accept new point
       a1 = log(0);
    end

    % define acceptance      
    if a1 >= 1
        % if more likely, accept
        accepted = true;
    else
        % if less likely, accept randomly
        xx = log(rand(1,1));
        if xx < a1
           accepted = true;
        end
    end    
end


function y=step(x)
%% Heaviside function (0 for x < 0; 1 otherwize) 
   y=zeros(size(x));
   isel = find(x>=0);
   if not(isempty(isel))
       y(isel)=1;
   end       
end
