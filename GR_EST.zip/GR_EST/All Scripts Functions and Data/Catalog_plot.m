function Catalog_plot( Catalog )

% This function plots time (in years) versus magnitude for a seismic catalog 

% INPUT
%
% Catalog : seismic catalog in ZMAP format

% computes the year of all the events (considering also month and day)
Years = Catalog( : , 3 ) + ( datenum(   Catalog( : , [ 3 : 5 , 8 : 10 ] ) ) - ...
                             datenum( [ Catalog( : , 3 ) , ones( size( Catalog , 1 ) , 1 )* ...
                             [1 , 1 , 0 , 0 , 0 ] ] ) )./ 365.25 ;
    
% plots year vs magnitude                         
plot( Years , Catalog( : , 6 ) , '.' )

% labels for X and Y axis
xlabel( 'Year' )
ylabel( 'Magnitude' )