function LL = LL_TaperedGR_Weichert_MCMC( MagnitudeVector , NumberEvents , Times , Lambda , Beta , CornerMagnitude ) 

% This function computes the log-likelihood of Tapered Gutenberg-Richter 
% distribution with the Weichert method for the MCMC uncertainty
% computation: in this case there is an upper maximum value for the Corner
% Magnitude to avoid computational problems (in the last part of the code
% is possible to change this value; by default set to Mw = 10.0 ) and a
% cutoff for unphysical negative values of Lambda and Beta

% INPUT
%
% MagnitudeVector : vector with the magnitudes of each bin  
% (e.g. [ 3.0 : 0.1 : 7.5 ] ) 
% 
% NumberEvents : output of the 'Weichert_Input' function
%
% Times : output of the 'Weichert_Input' function
%
% Lambda : annual rate of the events
%
% Beta : parameter of the Tapered GR distribution
%
% CornerMagnitude : parameter of the Tapered GR distribution

% OUTPUT
%
% LL : log-likelihood of the Tapered GR distribution given the parameters 
% computed using the Weichert approach


% pre-computation of the factorial logarithm to avoid overflow problem
for k = 1 : size( NumberEvents )
    
    if NumberEvents(k) > 0
    
        LOGFACT(k) = sum( log( [ NumberEvents(k) : -1 : 1 ] ) ) ;
    
    else
        LOGFACT(k) = 0;
    end
end
%

% convert magnitudes to moments (the specific law used in this conversion
% do not affect the final computation)
MagnBinM    = 10.^( 3/2*( MagnitudeVector + 10.733) ) ;      % convert magnitude bins to seismic moment
CornerMagnM = 10.^( 3/2*( CornerMagnitude + 10.733) ) ;      % convert corner magnitude to seismic moment
MagnComplM  = 10.^( 3/2*( min(MagnitudeVector) + 10.733) ) ; % convert magnitude of completeness to seismic moment



% compute the probability vector (in this case it uses the Tapered GR
% distribution)
Pr = (( MagnComplM )^Beta)*exp( MagnComplM/CornerMagnM )*...
     ((exp( -MagnBinM(1:end-1)/CornerMagnM )./(( MagnBinM(1:end-1) ).^Beta) ) - ...
      (exp( -MagnBinM(2:end  )/CornerMagnM )./(( MagnBinM(2:end  ) ).^Beta) )) ;
        
% compute the log-likelihood using the Weichert approach
LL = sum(NumberEvents)*log(Lambda) - Lambda*sum(Pr.*Times) +...
     sum(NumberEvents.*log(Pr.*Times) - LOGFACT ) ;
 
% assign a zero value for the likelihood if 'CornerMagnitude' is bigger 
% than a critical value or Lambda or Beta are <= 0
if CornerMagnitude >= 10.0 || Lambda <= 0 || Beta <= 0
    
    LL = log( 0 ) ;
    
end

             