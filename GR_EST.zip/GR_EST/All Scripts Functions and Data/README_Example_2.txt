Example 2 shows how to estimate the Beta and Corner Magnitude parameters for the Tapered GR distribution, with their uncertainties, from a seismic catalog.
The script also computes the B-value, that is 3/2 times the Beta parameter.

To reproduce the example and relative plot of the 95% confidence region for Beta and corner Magnitude, follow the instructions below:

1) run the script: Script_Bvalue_BetaAndCornerMagnitude_uncert.m
   This script computes the B-value and its uncertainty, and the 95% confidence region for Beta and Corner Magnitude. 
   The adopted confidence interval is set in line 50 in the function TaperedGR_Estimation_uncert.m, and it is possible to change this value if other confidence levels are needed.
   This script uses the two functions: Bvalue_Estimation_uncert.m , TaperedGR_Estimation_uncert.m
   Input: seismic catalog, column of the magnitude in the catalog (for ZMAP format is the 6th column), binning of the magnitude; 
   Ouput: figure with the MLE estimation and the 95% confidence interval of the Beta and Corner Magnitude parameters;







