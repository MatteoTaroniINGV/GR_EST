% This script compute the uncertainties for the estimated parameters of the  
% Truncated GR distribution using a Monte Carlo Markov Chain approach applied
% to the Kijko and Sellevoll method

% load the catalog in ZMAP format 
Catalog = load( 'Catalog_Simulation_TrGR.txt' ) ;
 
% load the completeness file in the two-columns format:
%     1                  2
% Magnitude   Starting year of completenss
CompletenessMatrix = load( 'Completeness_Matrix_Simulation.txt' ) ;

% last year of the catalog
CatalogEndingYear = 2000 ;

% vector of the magnitude bins
% !!! The maximum of the magnitude vector is also the maximum magnitude in
%     the Kijko and Sellevoll method !!! 
MagnitudeVector = 3.0 : 0.1 : 7.5 ;


% compute the info needed for the plot of the observed annual rate
[ NumberEvents , Times ] = Weichert_Input( Catalog , CompletenessMatrix , CatalogEndingYear , MagnitudeVector ) ;

% check for empty catalog
if sum( NumberEvents ) == 0
    
    disp( 'Empty Catalog!!' )
end


%%% parameters' uncertainty estimation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% log-likelihood function
LL_fun = {@( Par ) LL_TruncatedGR_KS_MCMC( Catalog , CompletenessMatrix , CatalogEndingYear , MagnitudeVector , Par(1) , Par(2) ) } ;

% starting values of the parameters for MCMC
Par_0 = [ 1 , 0.67 ] ;

% starting Sigma for the MCMC
SigmaGuess = [ 0.05 , 0.05 ] ;

% names of the parameters
Par_Names = { '\lambda' , '\b-value' } ;

% number of simulations in the MCMC
nsample = 10^3 ;

% MCMC computation
[ xout , figout ] = MCMC_uncert_Estimation( nsample , Par_0 , LL_fun , SigmaGuess , Par_Names ) ;    

%%% end uncertainty estimation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% assign the values at each parameter vector
LambdaVector = xout( : , 1 ) ;
BvalueVector = xout( : , 2 ) ;

% percentiles of the distribution that will be showing in the plot
Percentiles = [ 2.5 , 50 , 97.5 ] ;

% plot the percentiles of the estimated distribution
TruncatedGR_uncert_plot( MagnitudeVector , LambdaVector , BvalueVector , Percentiles )

hold on ; box on

% plot the observed cumulative annual rate
CumulativeAnnualRate_plot( MagnitudeVector , NumberEvents , Times )

% labels for X and Y axis
xlabel( 'Magnitude' )
ylabel( 'Log10 Cumulative Annual Rate' )