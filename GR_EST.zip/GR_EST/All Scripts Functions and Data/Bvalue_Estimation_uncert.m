function [ B , N , Sigma ] = Bvalue_Estimation_uncert( Data , MagnitudeColumn , MagnMin , Bin )

% INPUT
%
% Data : seismic catalog
%
% MagnitudeColumn : the magnitude column of the catalog
%
% MagnMin : minimum magnitude of completeness of the catalog
%
% Bin : bin of the magnitudes in the catalog (usually for Mw is 0.01
% and for Ml is 0.1);


% OUTPUT 
%
% B : b-value Maximum Likelihood Estimation (of the Gutenberg-Richter law) 
% taking into account the bin of the magnitudes 
%
% N : total number of events bigger or equal to MagnMin
%
% Sigma : b-value uncertainty


% select the events above the magnitude of completeness
DataOk = Data( Data( : , MagnitudeColumn ) > MagnMin - 10^(-6) , MagnitudeColumn ) ;
      
% number of events in the catalog
N = length( DataOk ); 

% compute the b-value 
B = (N-1)/N * 1/( log(10)*( mean( DataOk ) - ( MagnMin - Bin/2 ) ) ) ; 

% compute the b-value uncertainty
Sigma = B/sqrt( N ) ;
