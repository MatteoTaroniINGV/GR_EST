function TaperedGR_uncert_plot( MagnitudeVector , LambdaVector , BetaVector , CornerMagnitudeVector , Percentiles )
    
% This function plots the uncertainties percentiles of the cumulative Tapered Gutenberg-Richter distribution
% Tapered Gutenberg-Richter distribution in a logartihmc scale

% INPUT 
%
% MagnitudeVector : vector with the magnitudes of each bin 
%
% LambdaVector : vector of annual rate of the events
%
% BetaVector : vector of  the parameter of the Tapered GR distribution
%
% CornerMagnitudeVector : vector of the parameter of the Tapered GR distribution
%
% Percentiles : vector of percentiles that will be shown in the plot


% preallocation of annual rate matrix 
Rates = zeros( length( LambdaVector ) , length( MagnitudeVector ) ) ;

for i = 1 : length( LambdaVector )

    % convert magnitudes to moments (the specific law used in this conversion
    % do not affect the final computation)
    MagnBinM    = 10.^( 3/2*( MagnitudeVector + 10.733) ) ;            % convert magnitude bins to seismic moment
    CornerMagnM = 10.^( 3/2*( CornerMagnitudeVector( i ) + 10.733) ) ; % convert corner magnitude to seismic moment
    MagnComplM  = 10.^( 3/2*( min(MagnitudeVector) + 10.733) ) ;       % convert magnitude of completeness to seismic moment
  
    % cdf of the Tapered GR distribution
    F = 1 - ( ( ( ( MagnBinM ).^( -1 ) ).*MagnComplM ).^BetaVector( i ) ).*exp( ( MagnComplM - MagnBinM )./CornerMagnM ) ; 

    % compute the annual rates 
    Rates( i , : ) = ( 1 - F )*LambdaVector( i ) ; 

end    
    


% plot of the percentiles

figure(1)

hold on

for j = 1 : length( Percentiles ) 

    % compute percentile for each magnitude bin
    Perc_Rate = prctile( Rates , Percentiles( j ) ) ;
    
    % logarithmic plot of the selected percentile curve
    plot( MagnitudeVector , log10( Perc_Rate ) , '--r' ) 

end

