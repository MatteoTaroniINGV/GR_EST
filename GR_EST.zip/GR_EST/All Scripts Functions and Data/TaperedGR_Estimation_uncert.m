function TaperedGR_Estimation_uncert( Data , MagnitudeColumn , MagnMin , BetaVector , CornerMagnitudeVector )

% This function computes and plots the 95% confidence interval of the parameters
% of Tapered Gutenberg-Richter law using the "profile likeilhood method"

% INPUT
%
% Data : seismic catalog
%
% MagnitudeColumn : the magnitude column of the catalog
%
% MagnMin : minimum magnitude of completeness of the catalog
%
% BetaVector : vector of  the parameter of the Tapered GR distribution
%
% CornerMagnitudeVector : vector of the parameter of the Tapered GR distribution


% compute the length of the vectors of parameters
n1 = length( BetaVector ) ;
n2 = length( CornerMagnitudeVector ) ;

% number of events in the catalog
N = size( Data , 1 ) ;  

% convert magnitudes to moments (the specific law used in this conversion
% do not affect the final computation)
Moments = 10.^(3/2*( Data( : , MagnitudeColumn ) + 10.733 ) ) ; % convert magnitudes to seismic moment
Mt = 10.^(3/2*( MagnMin + 10.733 ) ) ;                          % convert MagnMin to seismic moment
Mc = 10.^(3/2*( CornerMagnitudeVector + 10.733 ) ) ;            % convert CornerMagnitudeVector to seismic moment

% preallocation of the log-likelihood matrix
LL = zeros( n1 , n2 ) ;  

for i = 1 : n1
    for j = 1 : n2
        
        LL( i , j ) = N*BetaVector(i)*log( Mt )+1/Mc(j)*( N*Mt - sum( Moments ) ) - ...
                      BetaVector(i)*sum( log( Moments ) ) + sum( log( BetaVector(i)./Moments + 1/Mc(j) ) ) ;
        % compute the log-likelihood for the Tapered Gutenberg-Richter distribution
    end
end


% maximum log-likelihood
LLmax = max( max( LL ) ) ;  

% 95% confidence interval with the "profile likeilhood method", is it
% possible to change this value to obtain different confidence intervals
LL95 = LLmax - 2.995 ; 

% contour plot of the log-likelihood and 95% confidence interval
[ C , h ] = contour( BetaVector , CornerMagnitudeVector , LL' , [LL95 LL95] ) ; 

hold on ; box on

% find the MLE values for the parameters
[ BetaIndex , McIndex ] = find( LL == LLmax ) ;

% plot the MLE point estimation
plot( BetaVector( BetaIndex ) , CornerMagnitudeVector( McIndex ) , '.' )

% labels for X and Y axis
xlabel( 'Beta' )
ylabel( 'Corner Magnitude' )

hold off
