Example 3 shows how to compute the maximum likelihood estimation (MLE) for Lambda, Beta and Corner Magnitude parameter of the tapered GR distribution, 
from a seismic catalog with variable completeness time windows. It uses the Kijko & Sellevoll 1989 approach.

To reproduce the example and relative plot with observed annual rate and the estimated Tapered GR distribution, follow the instructions below:

1) run the script: Script_TaperedGR_KS_Estimation.m
   This script compute the MLE estimation for Lmabda, Beta and Corner Magnitude parameter of the Tapered GR distribution.
   This script uses the functions: LL_TaperedGR_KS.m, Weichert_Input.m, CumulativeAnnualRate_plot.m, TaperedGR_plot.m
   Input: seismic catalog, matrix of completeness, ending year of the catalog, vector of the magnitude bins;
   Ouput: figure (magnitude vs log10 cumulative number of events plot) with observations and the estimated function;
