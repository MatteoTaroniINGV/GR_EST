% Script for the event selection in an seismic catalog (ZMAP format)
% accoridng to a completeness matrix (two-column format: magnitude year)


% load the catalog in ZMAP format
Catalog = Catalog ;

% load the completeness file in the two-columns format:
%     1                  2
% Magnitude   Starting year of completeness
CompletenessMatrix = load( 'Completeness_Matrix_Simulation.txt' ) ;


% initialization of the final catalog
Catalog_Final = [] ;

% counter needed in the 'for' cycle
Counter = 1 ;

for i =  1 : size( Catalog , 1 )
    
    % find the index relative to the correct line of the completeness matrix
    % if there is one
    Index = max( find( Catalog( i , 3 ) > CompletenessMatrix( : , 2) - 10^(-6) ) ) ;
    
    % if there is an index, second check for the magnitude of the events
    if ~isempty( Index ) && Catalog( i , 6 ) > CompletenessMatrix( Index , 1 )
        
        % add the event to the final catalog
        Catalog_Final = [ Catalog_Final ; Catalog( i , : ) ] ;
        
        % update the counter
        Counter = Counter + 1 ;
    end
end

        
        