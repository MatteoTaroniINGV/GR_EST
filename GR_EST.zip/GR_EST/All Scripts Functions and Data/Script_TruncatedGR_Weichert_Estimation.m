% This script compute the MLE for the Truncated GR distribution with the
% 'brute-force' approach (gridded search of the maximum)

% load the catalog in ZMAP format 
Catalog = load( 'Catalog_Simulation_TrGR.txt' ) ;
 
% load the completeness file in the two-columns format:
%     1                  2
% Magnitude   Starting year of completenss
CompletenessMatrix = load( 'Completeness_Matrix_Simulation.txt' ) ;

% last year of the catalog
CatalogEndingYear = 2000 ;

% vector of the magnitude bins
% !!! The maximum of the magnitude vector is also the maximum magnitude in
%     the Weichert method !!! 
MagnitudeVector = 3.0 : 0.1 : 7.5 ;


% compute the input necessary for the Weichert computation
[ NumberEvents , Times ] = Weichert_Input( Catalog , CompletenessMatrix , CatalogEndingYear , MagnitudeVector ) ;


%%% grid search for MLE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% possible values of the parameters for the grid search
LambdaVector =  90 : 0.5  : 110 ;
BvalueVector = 0.8 : 0.01 : 1.1 ;

% preallocation of the matrix with log-likelihood and parameters
Matrix_LL = zeros( length( LambdaVector )*length( BvalueVector ) , 3 ) ;

% counter needed in the 'for' cycle
Counter = 1 ; 

for i = 1 : length( LambdaVector )
    for j = 1 : length( BvalueVector )
            
        % compute the log-likelihood
        Matrix_LL( Counter , 1 ) = LL_TruncatedGR_Weichert( MagnitudeVector , ...
                                   NumberEvents , Times , LambdaVector(i) , ...
                                   BvalueVector(j) ) ;
            
        % save the values of the parameters
        Matrix_LL( Counter , 2 ) = LambdaVector(i) ;
        Matrix_LL( Counter , 3 ) = BvalueVector(j) ;
            
        % shows the remaining iterations (each ten iterations)
        if  mod( Counter , 10 ) == 0
                
            disp( [ 'Remaining iterations: ' num2str(size( Matrix_LL , 1 ) - Counter) ] )
            
        end
            
        % update the counter
        Counter = Counter + 1 ;
    end
end

% find the maximum likelihood and the relative index in the matrix
[ MaxLL , MaxIndex ] = max( Matrix_LL( : , 1 ) ) ;

% shows the MLE of the parameters
Lambda_MLE = Matrix_LL( MaxIndex , 2 ) 
Bvalue_MLE = Matrix_LL( MaxIndex , 3 ) 

%%% end of the grid search %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% plot the Truncated GR distribution with the MLE parameters
TruncatedGR_plot( MagnitudeVector , Lambda_MLE , Bvalue_MLE )

hold on ; box on

% plot the observed cumulative annual rate
CumulativeAnnualRate_plot( MagnitudeVector , NumberEvents , Times )

% labels for X and Y axis
xlabel( 'Magnitude' )
ylabel( 'Log10 Cumulative Annual Rate' )
