function LL = LL_TruncatedGR_KS_MCMC( Catalog , CompletenessMatrix , CatalogEndingYear , MagnitudeVector , Lambda , Bvalue )

% This function computes the log-likelihood of Tapered Gutenberg-Richter 
% distribution with the Kijko-Sellevol method for the MCMC uncertainty
% computation: in this case there is a cutoff for unphysical negative 
% values of Lambda and Bvalue

% INPUT
%
% Catalog : seismic catalog in ZMAP format
% 
% CompletenessMatrix : completeness matrix in the two-columns format:
%                            1                    2
%                        Magnitude      Starting year of completenss
%
% CatalogEndingYear : last year of the seismic catalog
%
% MagnitudeVector : the last value of this vector corresponds to the 
% maximum magnitude of the Truncated GR distribution
%
% Lambda : annual rate of the events
%
% Bvalue : parameter of the Truncated GR distribution

% OUTPUT
%
% LL : log-likelihood of the Truncated GR distribution given the parameters 
% computed using the Kijko-Sellevoll approach


% vector with all the magnitudes in the catalog
Magnitudes = Catalog( : , 6 ) ;

% vector with all the magnitudes of completeness
MagnCompl = CompletenessMatrix( : , 1 ) ;


for i = 1 : size( CompletenessMatrix , 1 )

    if i == size( CompletenessMatrix , 1 )
        
        % select the events in the correct magnitude-time window
        Magn_Sub_Catalog = Magnitudes( Magnitudes > MagnCompl(i)  - 10^(-6) & ...
                           Catalog(:,3) > CompletenessMatrix(i,2) - 10^(-6)  ) ;
          
        % number of events in the sub-catalog
        Num = length( Magn_Sub_Catalog ) ;
        
        % time length(in year) of the sub-catalog
        Time = CatalogEndingYear - CompletenessMatrix(i,2) + 1 ;
        
        % log-likelihood for the magnitude distribution
        L_M = Num*log( Bvalue*log(10) ) + (-1)*Bvalue*log(10)*sum( Magn_Sub_Catalog ) -...
              Num*log( exp( -Bvalue*log(10)*MagnCompl(i) ) - exp( -Bvalue*log(10)*max(MagnitudeVector) ) ) ;
        
        % ni (parameter for the log-likelihood computation)   
        ni = Lambda* ( 1 - ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*MagnCompl(i))))./...  
                           ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*max(MagnitudeVector))))) ;
                       
        % log-likelihood for the number of events distribution
        L_N = -ni*Time + Num*log( ni*Time ) ;
        
        % joint log-likelihood
        LL_Sub_Catalog( i ) = L_M + L_N ;
        
    else
        % select the events in the correct magnitude-time window
        Magn_Sub_Catalog = Magnitudes( (Magnitudes > MagnCompl(i) - 10^(-6)) & ...
                          (Catalog(:,3) > CompletenessMatrix(i,2) - 10^(-6))   & ...
                          (Catalog(:,3) < CompletenessMatrix(i+1,2)) ) ;
          
        % number of events in the sub-catalog
        Num = length( Magn_Sub_Catalog ) ;
        
        % time length(in year) of the sub-catalog
        Time = CompletenessMatrix(i+1,2) - CompletenessMatrix(i,2) + 1 ;
        
        % log-likelihood for the magnitude distribution
        L_M = Num*log( Bvalue*log(10) ) + (-1)*Bvalue*log(10)*sum( Magn_Sub_Catalog ) -...
              Num*log( exp( -Bvalue*log(10)*MagnCompl(i) ) - exp( -Bvalue*log(10)*max(MagnitudeVector) ) ) ;
        
        % ni (parameter for the log-likelihood computation)   
        ni = Lambda* ( 1 - ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*MagnCompl(i))))./...  
                           ((exp( -log(10)*Bvalue*min(MagnitudeVector)))-(exp( -log(10)*Bvalue*max(MagnitudeVector))))) ;
          
        % log-likelihood for the number of events distribution
        L_N = -ni*Time + Num*log( ni*Time ) ;
        
        % joint log-likelihood
        LL_Sub_Catalog( i ) = L_M + L_N ;              
    end
end

% compute the final log-likelihood
LL = sum( LL_Sub_Catalog ) ;

% assign a zero value for the likelihood if Lambda or Bvalue are <= 0
if Lambda <= 0 || Bvalue <= 0
    
    LL = log( 0 ) ;
    
end
