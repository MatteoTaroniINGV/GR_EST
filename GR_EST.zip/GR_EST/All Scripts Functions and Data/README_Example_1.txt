Example 1 shows how to create an earthquake synthetic catalog with variable completeness time windows and following a truncated GR magnitude-frequency distribution. 
Also the Tapered may be used by using the corresponding script (EarthquakeCatalogSimulation_TaperedGR.m).

To reproduce the example and relative plots, follow the instructions below:

1) run the script: EarthquakeCatalogSimulation_TruncatedGR.m
   This script creates a Poissonian synthetic earthquake catalog with a Truncated GR magnitude distribution and uniform magnitude of completeness. 
   Input:  Starting data, Annual rate, Longitude, Latitude, Depth, Minimum magnitude, Maximum magnitude, B-value, Number of events;
   Output: seismic catalog in ZMAP format;

2) run the script: Script_Event_Selection.m
   This script selects the events that meet the completeness condition in Completeness_Matrix_Simulation.txt
   Input:  seismic catalog (from previous script), matrix of completeness;
   Output: seismic catalog in ZMAP format (events in the complete part of the input catalog);

3) run the command line in the command window: Catalog_plot( Catalog_Final )
   This command line plots the event selected by Script_Event_Selection.m in a time vs magnitude plot.
   Input:  seismic catalog (from previuos script);
   Output: figure (years vs magnitude plot);



