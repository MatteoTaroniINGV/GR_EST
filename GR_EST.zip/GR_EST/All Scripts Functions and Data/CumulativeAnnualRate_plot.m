function CumulativeAnnualRate_plot( MagnitudeVector , NumberEvents , Times )

% This function plot the observed cumulative annual rate in a logarithmic
% scale

% INPUT
%
% MagnitudeVector : vector with the magnitudes of each bin 
%
% NumberEvents : output of the 'Weichert_Input' function
%
% Times : output of the 'Weichert_Input' function


for i = 1 : length( MagnitudeVector ) - 1
    
    % compute the incremental annual rate
    IncrementalAnnualRate( i ) = NumberEvents( i ) / Times( i ) ;
end

% compute the cumulative annual rate
CumulativeAnnualRate = fliplr( cumsum( fliplr( IncrementalAnnualRate ) ) ) ;

% plot the cumulative annual rate in a logarithmic scale
plot( MagnitudeVector( 1 : end - 1 ) , log10( CumulativeAnnualRate ) , 'ob' )
