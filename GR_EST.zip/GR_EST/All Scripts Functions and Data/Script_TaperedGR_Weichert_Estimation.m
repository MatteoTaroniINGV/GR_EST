% This script compute the MLE for the Tapered GR distribution with the
% 'brute-force' approach (gridded search of the maximum) applied to the
% Weichert method

% load the catalog in ZMAP format
Catalog = load( 'Catalog_Simulation_Ex3.txt' ) ;

% load the completeness file in the two-columns format:
%     1                  2
% Magnitude   Starting year of completenss
CompletenessMatrix = load( 'Completeness_Matrix_Simulation.txt' ) ;

% last year of the catalog
CatalogEndingYear = 1995 ;

% vector of the magnitude bins (needed for the plots)
MagnitudeVector = 3.0 : 0.1 : 7.5 ;

% compute the input necessary for the Weichert computation
[ NumberEvents , Times ] = Weichert_Input( Catalog , CompletenessMatrix , CatalogEndingYear , MagnitudeVector ) ;


%%% grid search for MLE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% possible values of the parameters for the grid search
LambdaVector          =  90 : 0.5  : 110 ;
BetaVector            = 0.6 : 0.01 : 0.7 ;
CornerMagnitudeVector = 5.5 : 0.1  : 7.5 ;

% preallocation of the matrix with log-likelihood and parameters
Matrix_LL = zeros( length( LambdaVector )*length( BetaVector )*length( CornerMagnitudeVector ) , 4 ) ;

% counter needed in the 'for' cycle
Counter = 1 ; 

for i = 1 : length( LambdaVector )
    for j = 1 : length( BetaVector )
        for k = 1 : length( CornerMagnitudeVector )
            
            % compute the log-likelihood
            Matrix_LL( Counter , 1 ) = LL_TaperedGR_Weichert( MagnitudeVector , ...
                                       NumberEvents , Times , LambdaVector(i) , ...
                                       BetaVector(j) , CornerMagnitudeVector(k) ) ;
            
            % save the values of the parameters
            Matrix_LL( Counter , 2 ) = LambdaVector(i) ;
            Matrix_LL( Counter , 3 ) = BetaVector(j) ;
            Matrix_LL( Counter , 4 ) = CornerMagnitudeVector(k) ;
            
            % shows the remaining iterations (each ten iterations)
            if  mod( Counter , 10 ) == 0
                
                disp( [ 'Remaining iterations: ' num2str(size( Matrix_LL , 1 ) - Counter) ] )
            
            end
            
            % update the counter
            Counter = Counter + 1 ;
        end
    end
end

% find the maximum likelihood and the relative index in the matrix
[ MaxLL , MaxIndex ] = max( Matrix_LL( : , 1 ) ) ;

% shows the MLE of the parameters
Lambda_MLE          = Matrix_LL( MaxIndex , 2 ) 
Beta_MLE            = Matrix_LL( MaxIndex , 3 ) 
CornerMagnitude_MLE = Matrix_LL( MaxIndex , 4 )

%%% end of the grid search %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% plot the Tapered GR distribution with the MLE parameters
TaperedGR_plot( MagnitudeVector , Lambda_MLE , Beta_MLE , CornerMagnitude_MLE )

hold on ; box on

% plot the observed cumulative annual rate
CumulativeAnnualRate_plot( MagnitudeVector , NumberEvents , Times )

% labels for X and Y axis
xlabel( 'Magnitude' )
ylabel( 'Log10 Cumulative Annual Rate' )






