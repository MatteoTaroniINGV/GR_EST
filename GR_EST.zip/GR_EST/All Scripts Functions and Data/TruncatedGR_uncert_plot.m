function TruncatedGR_uncert_plot( MagnitudeVector , LambdaVector , BvalueVector , Percentiles )
    
% This function plots the uncertainties percentiles of the cumulative Tapered Gutenberg-Richter distribution
% Tapered Gutenberg-Richter distribution in a logartihmc scale

% INPUT 
%
% MagnitudeVector : vector with the magnitudes of each bin 
%
% LambdaVector : vector of annual rate of the events
%
% BvalueVector : vector of  the parameter of the Truncated GR distribution
%
% Percentiles : vector of percentiles that will be shown in the plot


% preallocation of annual rate matrix 
Rates = zeros( length( LambdaVector ) , length( MagnitudeVector ) ) ;

for i = 1 : length( LambdaVector )

    % cdf of the Truncated GR distribution
    F = ((exp( -log(10)*BvalueVector( i )*min(MagnitudeVector)))-(exp( -log(10)*BvalueVector( i )*MagnitudeVector)))./...  
        ((exp( -log(10)*BvalueVector( i )*min(MagnitudeVector)))-(exp( -log(10)*BvalueVector( i )*max(MagnitudeVector)))) ;

    % compute the annual rates 
    Rates( i , : ) = ( 1 - F )*LambdaVector( i ) ; 

end    


% plot of the percentiles

figure(1)

hold on

for j = 1 : length( Percentiles ) 

    % compute percentile for each magnitude bin
    Perc_Rate = prctile( Rates , Percentiles( j ) ) ;
    
    % logarithmic plot of the selected percentile curve
    plot( MagnitudeVector , log10( Perc_Rate ) , '--r' ) 

end
