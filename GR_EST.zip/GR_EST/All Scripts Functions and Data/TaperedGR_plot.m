function TaperedGR_plot( MagnitudeVector , Lambda , Beta , CornerMagnitude )
    
% This function plots the cumulative Tapered Gutenberg-Richter distribution
% in a logartihmc scale

% INPUT 
%
% MagnitudeVector : vector with the magnitudes of each bin 
%
% Lambda : annual rate of the events
%
% Beta : parameter of the Tapered GR distribution
%
% CornerMagnitude : parameter of the Tapered GR distribution


% convert magnitudes to moments (the specific law used in this conversion
% do not affect the final computation)
MagnBinM    = 10.^( 3/2*( MagnitudeVector + 10.733) ) ;      % convert magnitude bins to seismic moment
CornerMagnM = 10.^( 3/2*( CornerMagnitude + 10.733) ) ;      % convert corner magnitude to seismic moment
MagnComplM  = 10.^( 3/2*( min(MagnitudeVector) + 10.733) ) ; % convert magnitude of completeness to seismic moment
  
% cdf of the Tapered GR distribution
F = 1 - ( ( ( ( MagnBinM ).^( -1 ) ).*MagnComplM ).^Beta ).*exp( ( MagnComplM - MagnBinM )./CornerMagnM ) ; 

% logarithmic plot of the cumulative Tapered GR distribution
plot( MagnitudeVector , log10( ( 1 - F ).*Lambda ) , 'r' ) 
