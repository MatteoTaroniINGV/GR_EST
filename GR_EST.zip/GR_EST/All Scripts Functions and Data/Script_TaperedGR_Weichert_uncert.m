% This script compute the uncertainties for the estimated parameters of the  
% Tapered GR distribution using a Monte Carlo Markoc Chain approach applied
% to the Weichert method

% load the catalog in ZMAP format 
Catalog = load( 'Catalog_Simulation_Ex4.txt' ) ;
 
% load the completeness file in the two-columns format:
%     1                  2
% Magnitude   Starting year of completenss
CompletenessMatrix = load( 'Completeness_Matrix_Simulation.txt' ) ;

% last year of the catalog
CatalogEndingYear = 1995 ;

% vector of the magnitude bins
MagnitudeVector = 3.0 : 0.1 : 7.5 ;

% compute the input necessary for the Weichert computation
[ NumberEvents , Times ] = Weichert_Input( Catalog , CompletenessMatrix , CatalogEndingYear , MagnitudeVector ) ;

% check for empty catalog
if sum( NumberEvents ) == 0
    
    disp( 'Empty Catalog!!' )
end


%%% parameters' uncertainty estimation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% log-likelihood function
LL_fun = {@( Par ) LL_TaperedGR_Weichert_MCMC( MagnitudeVector , NumberEvents , Times , Par(1) , Par(2) , Par(3) ) } ;

% starting values of the parameters for MCMC
Par_0 = [ 0.5 , 0.67 , 7 ] ;

% starting Sigma for the MCMC
SigmaGuess = [ 0.05 , 0.05 , 0.05 ] ;

% names of the parameters
Par_Names = { '\lambda' , '\beta' , 'Corner Magnitude' } ;

% number of simulations in the MCMC
nsample = 10^3 ;

% MCMC computation
[ xout , figout ] = MCMC_uncert_Estimation( nsample , Par_0 , LL_fun , SigmaGuess , Par_Names ) ;    

%%% end uncertainty estimation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% assign the values at each parameter vector
LambdaVector          = xout( : , 1 ) ;
BetaVector            = xout( : , 2 ) ;
CornerMagnitudeVector = xout( : , 3 ) ;

% percentiles of the distribution that will be showing in the plot
Percentiles = [ 2.5 , 50 , 97.5 ] ;

% plot the percentiles of the estimated distribution
TaperedGR_uncert_plot( MagnitudeVector , LambdaVector , BetaVector , CornerMagnitudeVector , Percentiles )

hold on ; box on

% plot the observed cumulative annual rate
CumulativeAnnualRate_plot( MagnitudeVector , NumberEvents , Times )

% labels for X and Y axis
xlabel( 'Magnitude' )
ylabel( 'Log10 Cumulative Annual Rate' )
