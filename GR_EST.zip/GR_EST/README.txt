GR_EST is as octave/matlab toolbox for the estimation of the Truncated and Tapered Gutenberg-Richter distribution parameters and thier uncertainty.
Some other useful functions (e.g. catalogs simulation) are also included in the toolbox.

Some scripts use a grid-serch approach to find the maximum likelikihood estimation (MLE), so you have to tune the parameters intervals of the grid to obtain the best solution.
This is a very important task, so please for MLE estimations TUNE THE PARAMETERS INTERVALS in a proper way!

Some scripts use the Monte Carlo Markov Chain (MCMC) approach to compute the uncertainty associated with the parameter estimation, then in some pathological 
cases is it possible that there is no convergence in the chain and you have to stop the computation (wait at least some minutes before stopping the computation).
In these cases, some diagnostic may be provided by activating the visualization of the chain production (setting to "true" the variable FigureYN).
For the burninig phase of the Markov Chain simulation, a Kolmogorov-Smirnov test (KStest) is applied; in case of rejection, a disclaimer will appear in the
command window, until the test is passed: please do not stop the computation, just wait until the sampling begins. 


Both Weichert 1980 and Kijko & Sellevoll 1989 methods work also using a catalog with a single completeness window, you have just to put the magnitude 
of completeness and the staring year of the catalog in the 'CompletenessMatrix' file (e.g. [ 3.0 , 1980 ] ).


In the script for catalogs simulation you can change all the parameters to obtain the final simulation that you want; remember that you can simulate 
temporal and magnitude distributions, but not the spatial component of the catalog (longitude and latitude).


If you want to have a better description of the parameters uncertainty using the Monte Carlo Markov Chain approach, you may increase the number of the 
samples (changing the 'nsample' variabile).


This toolbox contains a lot of scripts and functions; more information about all of them is provided below. 
We developed four examples to show the potential use the toolbox and its scripts/functions: we suggest to start form these examples before moving to real catalogs. 
Each example is accompained by a specific README file (README_Example_n.txt, with n=1,2,3,4).


-----------------------------------------------------------
List of functions (18) and scripts (12) of GR_EST toolbox:
-----------------------------------------------------------

Bvalue_Estimation _uncert.m: estimates the b-value of the GR law and its uncertainty; 
TGR_Estimation_uncert.m: estimates the beta and corner magnitude of the Ta-GR law and their uncertainties;
Catalog_plot.m: plot the earthquake catalog (time vs magnitude);
CumulativeAnnualRate_plot.m: plot the observed cumulative magnitude-frequency distribution;
TruncatedGR_plot.m: plot the Tr-GR law, given the parameters;
TaperedGR_plot.m: plot the Ta-GR law, given the parameters;
TruncatedGR_uncert_plot.m: plot the uncertainty of the Tr-GR law, given the vector of parameters;
TaperedGR_uncert_plot.m: plot the uncertainty of the Tr-GR law, given the vector of parameters;
Weichert_Input.m: computes the input needed for the Weichert (1980) method;
LL_TruncatedGR_Weichert.m: log-likelihood function of the Tr-GR law for Weichert (1980) method;
LL_TaperedGR_Weichert.m: log-likelihood function of the Ta-GR law for Weichert (1980) method;
LL_TruncatedGR_KS.m: log-likelihood function of the Tr-GR law for Kijko & Sellevoll (1989) method;
LL_TaperedGR_KS.m: log-likelihood function of the Ta-GR law for Kijko & Sellevoll (1989) method;
LL_TruncatedGR_Weichert_MCMC.m: log-likelihood function of the Tr-GR law for Weichert (1980) method, for MCMC computation;
LL_TruncatedGR_KS_MCMC.m: log-likelihood function of the Tr-GR law for Kijko & Sellevoll (1989) method, for MCMC computation;
LL_TaperedGR_Weichert_MCMC.m: log-likelihood function of the Ta-GR law for Weichert (1980) method, for MCMC computation;
LL_TaperedGR_KS_MCMC.m: log-likelihood function of the Ta-GR law for Kijko & Sellevoll (1989) method, for MCMC computation;
MCMC_uncert_Estimation.m: function that sample the parameters uncertainty using a Monte Carlo Markov Chain approach;
Script_Bvalue_BetaAndCornerMagnitude_uncert.m: estimates the b-value of the GR law and its uncertainty and the beta and corner magnitude of the Ta-GR law and their uncertainties with MLE method;
EarthquakeCatalogSimulation_TruncatedGR.m: simulate a Poissonian earthquake catalog with a Tr-GR distribution for the magnitudes;
EarthquakeCatalogSimulation_TaperedGR.m: simulate a Poissonian earthquake catalog with a Ta-GR distribution for the magnitudes;
Script_Event_Selection.m: select the events in an earthquake catalog according to multiple completeness windows for magnitude.
Script_TruncatedGR_Weichert_Estimation.m: point estimate of lambda and  b-value of the Tr-GR law using the Weichert (1980) method;
Script_TaperedGR_Weichert_Estimation.m: point estimate of lambda,  beta and Mc of the Ta-GR law using the Weichert method;
Script_TruncatedGR_KS_Estimation.m: point estimate of lambda and  b-value of the Tr-GR law using the Kijko & Sellevoll (1989) method;
Script_TaperedGR_KS_Estimation.m: point estimate of lambda,  beta and Mc of the Ta-GR law using the Kijko & Sellevoll (1989) method;
Script_TruncatedGR_Weichert_uncert.m: uncertainty estimate of lambda and  b-value of the Tr-GR law using the Weichert (1980) method;
Script_TaperedGR_Weichert_uncert.m: uncertainty estimate of lambda,  beta and Mc of the Ta-GR law using the Weichert (1980) method;
Script_TruncatedGR_KS_uncert.m: uncertainty estimate of lambda and  b-value of the Tr-GR law using the Kijko & Sellevoll (1989) method;
Script_TaperedGR_KS_uncert.m: uncertainty estimate of lambda,  beta and Mc of the Ta-GR law using the Kijko & Sellevoll (1989) method;

-----------------------------------------------------------
Disclaimer
-----------------------------------------------------------
The Software is provided 'as is' without warranty of any kind, either express or implied, including, but not limited to, the implied warranties of fitness for a purpose, or the warranty of non-infringement. 
Without limiting the foregoing, the Authors make no warranty that:

the software will meet your requirements
the software will be uninterrupted, timely, secure or error-free
the results that may be obtained from the use of the software will be effective, accurate or reliable
the quality of the software will meet your expectations
any errors in the software obtained will be corrected.

Software and its documentation made could include technical or other mistakes, inaccuracies or typographical errors. The Authors make no commitment to update such materials.
The Authors assume no responsibility for errors or ommissions in the software or documentation available from its web site.

In no event shall the Authors be liable to you or any third parties for any special, punitive, incidental, indirect or consequential damages of any kind, or any damages whatsoever, 
including, without limitation, those resulting from loss of use, data or profits, whether or not the Authors have been advised of the possibility of such damages, and on any theory 
of liability, arising out of or in connection with the use of this software.

The use of the software is done at your own discretion and risk and with agreement that you will be solely responsible for any damage this may cause, of any type, including damages 
to your computer system or loss of data that results from such activities. No advice or information, whether oral or written, obtained by you from the Authors shall create any 
warranty for the software.

-----------------------------------------------------------
Licence
-----------------------------------------------------------
A "Creative Commons Attribution-ShareAlike 4.0 International Public License". A detailed description of this licence More information can be found in 
https://creativecommons.org/licenses/by-sa/4.0/legalcode and in file LICENCE.txt.


